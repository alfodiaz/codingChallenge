// This works on all devices/browsers, and uses IndexedDBShim as a final fallback 
var indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB || window.shimIndexedDB;

// Open (or create) the database
var open = indexedDB.open("ArtistDatabase", 1);
export var artists = [];
// Create the schema
open.onupgradeneeded = function() {
    var db = open.result;
    var store = db.createObjectStore("ArtistStore", {keyPath: "id"});
    var index = store.createIndex("NameIndex", ["name"]);
};

open.onsuccess = function() {
    // Start a new transaction
    var db = open.result;
    var tx = db.transaction("ArtistStore", "readwrite");
    var store = tx.objectStore("ArtistStore");
    var index = store.index("NameIndex");

    // Add some data
    store.put({id: 1, name: "Mick Jagger"});
    store.put({id: 2, name: "Freddy Mercury"});
    store.put({id: 3, name: "Michael Jackson"});
    store.put({id: 4, name: "Whitney Houston"});
    store.put({id: 5, name: "John Lennon"});
    store.put({id: 6, name: "Ringo Star"});
    

    store.openCursor().onsuccess = function(event) {
      var cursor = event.target.result;
      if (cursor) {
          artists.push(cursor.value);
        console.log("artist:", cursor.value.name);
        // alert("Name for SSN " + cursor.key + " is " + cursor.value.name);
        cursor.continue();
      }
      else {
        //alert("No more entries!");
      }
    };

    // Query the data
    var getMickJagger = store.get(1);
    //var getBob = index.get(["Smith", "Bob"]);

    getMickJagger.onsuccess = function() {
        console.log("Mick Jagger: ",getMickJagger.result.name);  // => "Mick Jagger"
    };

   /* getBob.onsuccess = function() {
        console.log(getBob.result.name.first);   // => "Bob"
    };*/

    // Close the db when the transaction is done
    tx.oncomplete = function() {
        db.close();
    };

}
export default indexedDB;